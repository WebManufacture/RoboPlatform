// Initialize your app
var myApp = new Framework7({
    swipePanel: 'right'
});
// Export selectors engine
var $$ = Dom7;

var config1 = liquidFillGaugeDefaultSettings();
config1.circleThickness = 0.04;
config1.waveHeight = 0.1;
config1.waveCount = 0.5;
config1.textVertPosition = 0.5;
config1.waveAnimateTime = 1500;
var gauge1 = loadLiquidFillGauge("fillgauge1", 0, config1);

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    window.addEventListener("batterystatus", onBatteryStatus, false);
}

function onBatteryStatus(info) {

    var value = info.level;
    changeGraphOfBattery(value);
    changeBatteryPlugged(value,info.isPlugged);
}

function changeGraphOfBattery(value) {
    gauge1.update(value);
}

function changeBatteryPlugged(value,status) {
    if (status == true) {
        config1.circleColor = "#808015";
        config1.textColor = "#555500";
        config1.waveTextColor = "#FFFFAA";
        config1.waveColor = "#AAAA39";
        document.getElementById('fillgauge1').removeChild(document.getElementById('fillgauge1').firstChild);
        gauge1 = loadLiquidFillGauge("fillgauge1", value, config1);
    } else if(status == false) {
        config1.circleColor = "#FF7777";
        config1.textColor = "#FF4444";
        config1.waveTextColor = "#FFAAAA";
        config1.waveColor = "#FFDDDD";
        document.getElementById('fillgauge1').removeChild(document.getElementById('fillgauge1').firstChild);
        gauge1 = loadLiquidFillGauge("fillgauge1", value, config1);
    }
}


$$('.open-right-panel').on('click', function (e) {
    // 'right' position to open Right panel
    myApp.openPanel('right');
});

// Add views
var view1 = myApp.addView('#view-1');
var view2 = myApp.addView('#view-2', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true
});

var view3 = myApp.addView('#view-3');
var view4 = myApp.addView('#view-4');
