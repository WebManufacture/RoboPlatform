// Initialize your app
var myApp = new Framework7({
    swipePanel: 'right'
});
// Export selectors engine
var $$ = Dom7;

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    window.addEventListener("batterystatus", onBatteryStatus, false);
}

function onBatteryStatus(info) {
    alert("Level: " + info.level + " isPlugged: " + info.isPlugged);
}

$$('.open-right-panel').on('click', function (e) {
    // 'right' position to open Right panel
    myApp.openPanel('right');
});

// Add views
var view1 = myApp.addView('#view-1');
var view2 = myApp.addView('#view-2', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true
});
var view3 = myApp.addView('#view-3');
var view4 = myApp.addView('#view-4');

 function NewValue() {
     if (Math.random() > .5) {
         return Math.round(Math.random() * 100);
     } else {
         return (Math.random() * 100).toFixed(1);
     }
 }
